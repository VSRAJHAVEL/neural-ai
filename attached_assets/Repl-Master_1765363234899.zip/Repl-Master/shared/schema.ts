import { pgTable, text, varchar, jsonb, bigint } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const ComponentType = z.enum([
  "container",
  "text",
  "button",
  "image",
  "card",
  "navbar",
]);
export type ComponentType = z.infer<typeof ComponentType>;

export const ComponentPropsSchema = z.object({
  text: z.string().optional(),
  color: z.string().optional(),
  backgroundColor: z.string().optional(),
  url: z.string().optional(),
  imageUrl: z.string().optional(),
  fontSize: z.string().optional(),
  padding: z.string().optional(),
  width: z.string().optional(),
  height: z.string().optional(),
  alignment: z.enum(["left", "center", "right"]).optional(),
  borderRadius: z.string().optional(),
});
export type ComponentProps = z.infer<typeof ComponentPropsSchema>;

export const LayoutComponentSchema: z.ZodType<{
  id: string;
  type: ComponentType;
  props: ComponentProps;
  children?: any[];
}> = z.object({
  id: z.string(),
  type: ComponentType,
  props: ComponentPropsSchema,
  children: z.lazy(() => z.array(LayoutComponentSchema)).optional(),
});
export type LayoutComponent = z.infer<typeof LayoutComponentSchema>;

export const LayoutJsonSchema = z.object({
  components: z.array(LayoutComponentSchema),
});
export type LayoutJson = z.infer<typeof LayoutJsonSchema>;

export const GeneratedCodeSchema = z.object({
  jsx: z.string(),
  css: z.string().optional(),
  readme: z.string().optional(),
});
export type GeneratedCode = z.infer<typeof GeneratedCodeSchema>;

export const OptimizedCodeSchema = z.object({
  optimizedJsx: z.string(),
  notes: z.string().optional(),
});
export type OptimizedCode = z.infer<typeof OptimizedCodeSchema>;

export const ProjectSchema = z.object({
  id: z.string(),
  name: z.string().min(1).max(100),
  userId: z.string(),
  layout: LayoutJsonSchema,
  generatedCode: GeneratedCodeSchema.optional(),
  createdAt: z.number(),
  updatedAt: z.number(),
});
export type Project = z.infer<typeof ProjectSchema>;

export const GenerateRequestSchema = z.object({
  layoutJson: LayoutJsonSchema,
});
export type GenerateRequest = z.infer<typeof GenerateRequestSchema>;

export const OptimizeRequestSchema = z.object({
  jsx: z.string().min(1),
});
export type OptimizeRequest = z.infer<typeof OptimizeRequestSchema>;

export const ExportRequestSchema = z.object({
  projectName: z.string().min(1).max(100),
  layoutJson: LayoutJsonSchema,
  generatedCode: GeneratedCodeSchema.optional(),
});
export type ExportRequest = z.infer<typeof ExportRequestSchema>;

export const users = pgTable("users", {
  id: varchar("id", { length: 255 }).primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const projects = pgTable("projects", {
  id: varchar("id", { length: 255 }).primaryKey(),
  userId: varchar("user_id", { length: 255 }).notNull(),
  name: text("name").notNull(),
  layout: jsonb("layout").notNull(),
  generatedCode: jsonb("generated_code"),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
  updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type SelectProject = typeof projects.$inferSelect;
