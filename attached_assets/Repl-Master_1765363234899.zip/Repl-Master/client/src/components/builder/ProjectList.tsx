import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { useProject } from "@/context/ProjectContext";
import { getUserProjects, deleteProject, type Project } from "@/lib/firebase";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import {
  FolderOpen,
  Plus,
  Trash2,
  Loader2,
  FileCode,
  Calendar,
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface ProjectListProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ProjectList({ open, onOpenChange }: ProjectListProps) {
  const { user } = useAuth();
  const { setProjectId, setProjectName, setLayout, setGeneratedCode, resetProject } = useProject();
  const { toast } = useToast();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState<string | null>(null);

  useEffect(() => {
    if (open && user) {
      loadProjects();
    }
  }, [open, user]);

  const loadProjects = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const userProjects = await getUserProjects(user.uid);
      setProjects(userProjects);
    } catch (error: any) {
      toast({
        title: "Failed to load projects",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLoadProject = (project: Project) => {
    setProjectId(project.id);
    setProjectName(project.name);
    setLayout(project.layout);
    setGeneratedCode(project.generatedCode || null);
    onOpenChange(false);
    toast({
      title: "Project loaded",
      description: `"${project.name}" has been loaded.`,
    });
  };

  const handleDeleteProject = async (projectId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) return;

    setDeleting(projectId);
    try {
      await deleteProject(user.uid, projectId);
      setProjects((prev) => prev.filter((p) => p.id !== projectId));
      toast({
        title: "Project deleted",
        description: "The project has been deleted.",
      });
    } catch (error: any) {
      toast({
        title: "Delete failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setDeleting(null);
    }
  };

  const handleNewProject = () => {
    resetProject();
    onOpenChange(false);
    toast({
      title: "New project created",
      description: "Start building your new project.",
    });
  };

  if (!user) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Sign in required</DialogTitle>
            <DialogDescription>
              Please sign in to view and manage your projects.
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FolderOpen className="w-5 h-5" />
            Your Projects
          </DialogTitle>
          <DialogDescription>
            Load a saved project or create a new one
          </DialogDescription>
        </DialogHeader>

        <div className="py-2">
          <Button
            onClick={handleNewProject}
            className="w-full mb-4"
            data-testid="button-new-project"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Project
          </Button>

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : projects.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mx-auto mb-3">
                <FileCode className="w-5 h-5 text-muted-foreground" />
              </div>
              <p className="text-sm text-muted-foreground">No saved projects yet</p>
            </div>
          ) : (
            <ScrollArea className="h-[300px]">
              <div className="space-y-2">
                {projects.map((project) => (
                  <button
                    key={project.id}
                    onClick={() => handleLoadProject(project)}
                    className="w-full flex items-center gap-3 p-3 rounded-lg border bg-card text-left transition-colors hover-elevate group"
                    data-testid={`button-load-project-${project.id}`}
                  >
                    <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <FileCode className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{project.name}</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {formatDistanceToNow(project.updatedAt, { addSuffix: true })}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="flex-shrink-0 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive"
                      onClick={(e) => handleDeleteProject(project.id, e)}
                      disabled={deleting === project.id}
                      data-testid={`button-delete-project-${project.id}`}
                    >
                      {deleting === project.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4" />
                      )}
                    </Button>
                  </button>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
