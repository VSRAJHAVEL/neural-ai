import { useProject } from "@/context/ProjectContext";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { ComponentType } from "@shared/schema";
import {
  Square,
  Type,
  MousePointer2,
  Image,
  CreditCard,
  Navigation,
  Plus,
} from "lucide-react";

const COMPONENT_PALETTE: {
  type: ComponentType;
  label: string;
  icon: React.ReactNode;
  description: string;
}[] = [
  {
    type: "container",
    label: "Container",
    icon: <Square className="w-5 h-5" />,
    description: "A flexible container for layout",
  },
  {
    type: "text",
    label: "Text",
    icon: <Type className="w-5 h-5" />,
    description: "Text block with styling",
  },
  {
    type: "button",
    label: "Button",
    icon: <MousePointer2 className="w-5 h-5" />,
    description: "Interactive button element",
  },
  {
    type: "image",
    label: "Image",
    icon: <Image className="w-5 h-5" />,
    description: "Image with responsive sizing",
  },
  {
    type: "card",
    label: "Card",
    icon: <CreditCard className="w-5 h-5" />,
    description: "Card with content area",
  },
  {
    type: "navbar",
    label: "Navbar",
    icon: <Navigation className="w-5 h-5" />,
    description: "Navigation header bar",
  },
];

export function Sidebar() {
  const { addComponent } = useProject();

  const handleAddComponent = (type: ComponentType) => {
    addComponent(type);
  };

  return (
    <aside className="w-64 border-r bg-sidebar flex flex-col flex-shrink-0">
      <div className="p-4 border-b">
        <h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Components
        </h2>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-3 space-y-1">
          {COMPONENT_PALETTE.map((component) => (
            <Button
              key={component.type}
              variant="ghost"
              onClick={() => handleAddComponent(component.type)}
              className="w-full h-auto justify-start gap-3 px-4 py-3 group"
              data-testid={`button-add-${component.type}`}
            >
              <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-muted flex items-center justify-center text-muted-foreground group-hover:text-foreground group-hover:bg-accent transition-colors">
                {component.icon}
              </div>
              <div className="flex-1 min-w-0 text-left">
                <p className="text-sm font-medium text-foreground">{component.label}</p>
                <p className="text-xs text-muted-foreground truncate">{component.description}</p>
              </div>
              <div className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                <Plus className="w-4 h-4 text-muted-foreground" />
              </div>
            </Button>
          ))}
        </div>
      </ScrollArea>

      <div className="p-4 border-t">
        <div className="p-3 rounded-lg bg-muted/50">
          <p className="text-xs text-muted-foreground text-center">
            Click a component to add it to the canvas
          </p>
        </div>
      </div>
    </aside>
  );
}
