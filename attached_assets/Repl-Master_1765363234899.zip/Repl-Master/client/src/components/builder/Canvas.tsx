import { useProject } from "@/context/ProjectContext";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { LayoutComponent, ComponentType } from "@shared/schema";
import { cn } from "@/lib/utils";
import {
  Square,
  Type,
  MousePointer2,
  Image,
  CreditCard,
  Navigation,
  Trash2,
  GripVertical,
  ChevronUp,
  ChevronDown,
  Layers,
} from "lucide-react";

const COMPONENT_ICONS: Record<ComponentType, React.ReactNode> = {
  container: <Square className="w-4 h-4" />,
  text: <Type className="w-4 h-4" />,
  button: <MousePointer2 className="w-4 h-4" />,
  image: <Image className="w-4 h-4" />,
  card: <CreditCard className="w-4 h-4" />,
  navbar: <Navigation className="w-4 h-4" />,
};

function getComponentLabel(type: ComponentType): string {
  return type.charAt(0).toUpperCase() + type.slice(1);
}

interface CanvasComponentProps {
  component: LayoutComponent;
  index: number;
  totalCount: number;
  isSelected: boolean;
  onSelect: () => void;
  onRemove: () => void;
  onMoveUp: () => void;
  onMoveDown: () => void;
}

function CanvasComponent({
  component,
  index,
  totalCount,
  isSelected,
  onSelect,
  onRemove,
  onMoveUp,
  onMoveDown,
}: CanvasComponentProps) {
  return (
    <div
      onClick={onSelect}
      className={cn(
        "group relative bg-card border rounded-xl p-4 cursor-pointer transition-all",
        isSelected
          ? "ring-2 ring-primary shadow-md border-primary/50"
          : "hover:shadow-sm hover:border-muted-foreground/20"
      )}
      data-testid={`canvas-component-${component.id}`}
    >
      <div className="absolute left-2 top-1/2 -translate-y-1/2 flex flex-col gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6"
          onClick={(e) => {
            e.stopPropagation();
            onMoveUp();
          }}
          disabled={index === 0}
          data-testid={`button-move-up-${component.id}`}
        >
          <ChevronUp className="w-3 h-3" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6"
          onClick={(e) => {
            e.stopPropagation();
            onMoveDown();
          }}
          disabled={index === totalCount - 1}
          data-testid={`button-move-down-${component.id}`}
        >
          <ChevronDown className="w-3 h-3" />
        </Button>
      </div>

      <div className="ml-6 flex items-center gap-3">
        <div
          className={cn(
            "flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center",
            isSelected ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
          )}
        >
          {COMPONENT_ICONS[component.type]}
        </div>

        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium">{getComponentLabel(component.type)}</p>
          <p className="text-xs text-muted-foreground truncate">
            {component.props.text || component.props.imageUrl || `${component.type} element`}
          </p>
        </div>

        <div className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:text-destructive"
            onClick={(e) => {
              e.stopPropagation();
              onRemove();
            }}
            data-testid={`button-remove-${component.id}`}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="ml-6 mt-3 p-3 rounded-lg bg-muted/50 min-h-[60px]">
        <ComponentPreview component={component} />
      </div>
    </div>
  );
}

function ComponentPreview({ component }: { component: LayoutComponent }) {
  const { props, type } = component;

  switch (type) {
    case "container":
      return (
        <div
          className="rounded-md p-2 min-h-[40px] border-2 border-dashed border-muted-foreground/20"
          style={{
            backgroundColor: props.backgroundColor || "#f8fafc",
          }}
        >
          <span className="text-xs text-muted-foreground">Container</span>
        </div>
      );

    case "text":
      return (
        <p
          style={{
            color: props.color || "#1e293b",
            fontSize: props.fontSize || "14px",
            textAlign: props.alignment || "left",
          }}
          className="truncate"
        >
          {props.text || "Text content"}
        </p>
      );

    case "button":
      return (
        <button
          className="px-3 py-1.5 rounded-md text-sm font-medium transition-colors"
          style={{
            backgroundColor: props.backgroundColor || "#6366f1",
            color: props.color || "#ffffff",
          }}
        >
          {props.text || "Button"}
        </button>
      );

    case "image":
      return (
        <div className="flex items-center justify-center">
          <img
            src={props.imageUrl || "https://via.placeholder.com/120x80"}
            alt="Preview"
            className="max-h-16 rounded-md object-cover"
            style={{
              borderRadius: props.borderRadius || "8px",
            }}
          />
        </div>
      );

    case "card":
      return (
        <div
          className="rounded-lg p-3 border shadow-sm"
          style={{
            backgroundColor: props.backgroundColor || "#ffffff",
          }}
        >
          <p className="text-sm font-medium" style={{ color: props.color }}>
            {props.text || "Card Title"}
          </p>
        </div>
      );

    case "navbar":
      return (
        <div
          className="rounded-md px-3 py-2 flex items-center"
          style={{
            backgroundColor: props.backgroundColor || "#1e293b",
            color: props.color || "#ffffff",
          }}
        >
          <span className="text-sm font-medium">{props.text || "Navbar"}</span>
        </div>
      );

    default:
      return <span className="text-xs text-muted-foreground">Unknown component</span>;
  }
}

export function Canvas() {
  const { layout, selectedComponentId, setSelectedComponentId, removeComponent, moveComponent } =
    useProject();

  const handleDeselect = () => {
    setSelectedComponentId(null);
  };

  return (
    <div className="flex-1 flex flex-col bg-muted/30 overflow-hidden">
      <div className="p-4 border-b bg-background flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-medium">Canvas</span>
          <span className="text-xs text-muted-foreground">
            ({layout.components.length} component{layout.components.length !== 1 ? "s" : ""})
          </span>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-6" onClick={handleDeselect}>
          {layout.components.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-20 h-20 rounded-2xl bg-muted flex items-center justify-center mb-4">
                <Layers className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-medium mb-2">No components yet</h3>
              <p className="text-sm text-muted-foreground text-center max-w-xs">
                Click on components in the sidebar to add them to your canvas
              </p>
            </div>
          ) : (
            <div className="space-y-3 max-w-2xl mx-auto">
              {layout.components.map((component, index) => (
                <CanvasComponent
                  key={component.id}
                  component={component}
                  index={index}
                  totalCount={layout.components.length}
                  isSelected={selectedComponentId === component.id}
                  onSelect={() => setSelectedComponentId(component.id)}
                  onRemove={() => removeComponent(component.id)}
                  onMoveUp={() => moveComponent(index, index - 1)}
                  onMoveDown={() => moveComponent(index, index + 1)}
                />
              ))}
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
