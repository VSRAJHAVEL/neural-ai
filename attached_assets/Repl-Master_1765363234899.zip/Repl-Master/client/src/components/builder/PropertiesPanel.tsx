import { useProject } from "@/context/ProjectContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { ComponentProps } from "@shared/schema";
import {
  Settings2,
  Palette,
  Type,
  Image,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Trash2,
  Code2,
} from "lucide-react";

export function PropertiesPanel() {
  const { getSelectedComponent, updateComponent, removeComponent, selectedComponentId, generatedCode } =
    useProject();

  const selectedComponent = getSelectedComponent();

  const handleUpdateProp = (key: keyof ComponentProps, value: string) => {
    if (selectedComponentId) {
      updateComponent(selectedComponentId, { [key]: value });
    }
  };

  if (!selectedComponent) {
    return (
      <aside className="w-80 border-l bg-sidebar flex flex-col flex-shrink-0">
        <div className="p-4 border-b">
          <h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Properties
          </h2>
        </div>
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="text-center">
            <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mx-auto mb-3">
              <Settings2 className="w-5 h-5 text-muted-foreground" />
            </div>
            <p className="text-sm text-muted-foreground">
              Select a component to edit its properties
            </p>
          </div>
        </div>
      </aside>
    );
  }

  const { type, props } = selectedComponent;

  return (
    <aside className="w-80 border-l bg-sidebar flex flex-col flex-shrink-0">
      <div className="p-4 border-b flex items-center justify-between gap-2">
        <div>
          <h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Properties
          </h2>
          <p className="text-sm font-medium mt-0.5 capitalize">{type}</p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="text-muted-foreground hover:text-destructive"
          onClick={() => removeComponent(selectedComponentId!)}
          data-testid="button-delete-selected"
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>

      <Tabs defaultValue="style" className="flex-1 flex flex-col">
        <TabsList className="mx-4 mt-3 grid grid-cols-2">
          <TabsTrigger value="style" className="text-xs">
            <Palette className="w-3 h-3 mr-1" />
            Style
          </TabsTrigger>
          <TabsTrigger value="content" className="text-xs">
            <Type className="w-3 h-3 mr-1" />
            Content
          </TabsTrigger>
        </TabsList>

        <ScrollArea className="flex-1">
          <TabsContent value="style" className="mt-0 p-4 space-y-4">
            {(type === "container" || type === "button" || type === "card" || type === "navbar") && (
              <PropertyField label="Background Color">
                <div className="flex gap-2">
                  <Input
                    type="color"
                    value={props.backgroundColor || "#ffffff"}
                    onChange={(e) => handleUpdateProp("backgroundColor", e.target.value)}
                    className="w-12 h-9 p-1 cursor-pointer"
                    data-testid="input-background-color"
                  />
                  <Input
                    type="text"
                    value={props.backgroundColor || "#ffffff"}
                    onChange={(e) => handleUpdateProp("backgroundColor", e.target.value)}
                    className="flex-1"
                    placeholder="#ffffff"
                    data-testid="input-background-color-text"
                  />
                </div>
              </PropertyField>
            )}

            {(type === "text" || type === "button" || type === "navbar") && (
              <PropertyField label="Text Color">
                <div className="flex gap-2">
                  <Input
                    type="color"
                    value={props.color || "#1e293b"}
                    onChange={(e) => handleUpdateProp("color", e.target.value)}
                    className="w-12 h-9 p-1 cursor-pointer"
                    data-testid="input-text-color"
                  />
                  <Input
                    type="text"
                    value={props.color || "#1e293b"}
                    onChange={(e) => handleUpdateProp("color", e.target.value)}
                    className="flex-1"
                    placeholder="#1e293b"
                    data-testid="input-text-color-text"
                  />
                </div>
              </PropertyField>
            )}

            {type === "text" && (
              <PropertyField label="Font Size">
                <Select
                  value={props.fontSize || "16px"}
                  onValueChange={(value) => handleUpdateProp("fontSize", value)}
                >
                  <SelectTrigger data-testid="select-font-size">
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="12px">Small (12px)</SelectItem>
                    <SelectItem value="14px">Body (14px)</SelectItem>
                    <SelectItem value="16px">Medium (16px)</SelectItem>
                    <SelectItem value="18px">Large (18px)</SelectItem>
                    <SelectItem value="24px">Heading (24px)</SelectItem>
                    <SelectItem value="32px">Display (32px)</SelectItem>
                    <SelectItem value="48px">Hero (48px)</SelectItem>
                  </SelectContent>
                </Select>
              </PropertyField>
            )}

            {type === "text" && (
              <PropertyField label="Alignment">
                <div className="flex gap-1">
                  {[
                    { value: "left", icon: AlignLeft },
                    { value: "center", icon: AlignCenter },
                    { value: "right", icon: AlignRight },
                  ].map(({ value, icon: Icon }) => (
                    <Button
                      key={value}
                      variant={props.alignment === value ? "default" : "outline"}
                      size="sm"
                      className="flex-1"
                      onClick={() => handleUpdateProp("alignment", value as "left" | "center" | "right")}
                      data-testid={`button-align-${value}`}
                    >
                      <Icon className="w-4 h-4" />
                    </Button>
                  ))}
                </div>
              </PropertyField>
            )}

            <PropertyField label="Padding">
              <Input
                type="text"
                value={props.padding || ""}
                onChange={(e) => handleUpdateProp("padding", e.target.value)}
                placeholder="e.g., 16px or 8px 16px"
                data-testid="input-padding"
              />
            </PropertyField>

            <PropertyField label="Border Radius">
              <Input
                type="text"
                value={props.borderRadius || ""}
                onChange={(e) => handleUpdateProp("borderRadius", e.target.value)}
                placeholder="e.g., 8px"
                data-testid="input-border-radius"
              />
            </PropertyField>

            {type === "image" && (
              <>
                <PropertyField label="Width">
                  <Input
                    type="text"
                    value={props.width || ""}
                    onChange={(e) => handleUpdateProp("width", e.target.value)}
                    placeholder="e.g., 300px or 100%"
                    data-testid="input-width"
                  />
                </PropertyField>
                <PropertyField label="Height">
                  <Input
                    type="text"
                    value={props.height || ""}
                    onChange={(e) => handleUpdateProp("height", e.target.value)}
                    placeholder="e.g., 200px or auto"
                    data-testid="input-height"
                  />
                </PropertyField>
              </>
            )}
          </TabsContent>

          <TabsContent value="content" className="mt-0 p-4 space-y-4">
            {(type === "text" || type === "button" || type === "card" || type === "navbar") && (
              <PropertyField label="Text Content">
                <Textarea
                  value={props.text || ""}
                  onChange={(e) => handleUpdateProp("text", e.target.value)}
                  placeholder="Enter text content"
                  className="min-h-[80px] resize-none"
                  data-testid="input-text-content"
                />
              </PropertyField>
            )}

            {type === "image" && (
              <PropertyField label="Image URL">
                <Input
                  type="text"
                  value={props.imageUrl || ""}
                  onChange={(e) => handleUpdateProp("imageUrl", e.target.value)}
                  placeholder="https://example.com/image.jpg"
                  data-testid="input-image-url"
                />
              </PropertyField>
            )}

            {type === "button" && (
              <PropertyField label="Link URL">
                <Input
                  type="text"
                  value={props.url || ""}
                  onChange={(e) => handleUpdateProp("url", e.target.value)}
                  placeholder="https://example.com"
                  data-testid="input-link-url"
                />
              </PropertyField>
            )}
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </aside>
  );
}

function PropertyField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <Label className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
