import { useState } from "react";
import { useLocation } from "wouter";
import { useProject } from "@/context/ProjectContext";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { generateCode, optimizeCode, exportProject, downloadBlob } from "@/lib/api";
import { saveProject } from "@/lib/firebase";
import {
  Save,
  Sparkles,
  Zap,
  Download,
  LogOut,
  User,
  Loader2,
  Check,
  FolderOpen,
  ChevronDown,
  Moon,
  Sun,
} from "lucide-react";

interface TopbarProps {
  onOpenProjects: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export function Topbar({ onOpenProjects, isDarkMode, onToggleDarkMode }: TopbarProps) {
  const [, setLocation] = useLocation();
  const {
    projectId,
    projectName,
    setProjectName,
    layout,
    generatedCode,
    setGeneratedCode,
    isGenerating,
    setIsGenerating,
    isOptimizing,
    setIsOptimizing,
  } = useProject();
  const { user, signOut } = useAuth();
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [isEditingName, setIsEditingName] = useState(false);

  const handleSave = async () => {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to save your project.",
        variant: "destructive",
      });
      return;
    }

    setIsSaving(true);
    try {
      await saveProject(user.uid, projectId, {
        name: projectName,
        layout,
        generatedCode: generatedCode || undefined,
      });
      toast({
        title: "Project saved",
        description: "Your project has been saved successfully.",
      });
    } catch (error: any) {
      toast({
        title: "Save failed",
        description: error.message || "Failed to save project.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleGenerate = async () => {
    if (layout.components.length === 0) {
      toast({
        title: "No components",
        description: "Add some components to the canvas first.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    try {
      const code = await generateCode(layout);
      setGeneratedCode(code);
      toast({
        title: "Code generated",
        description: "AI has generated React + Tailwind code for your design.",
      });
    } catch (error: any) {
      toast({
        title: "Generation failed",
        description: error.message || "Failed to generate code.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleOptimize = async () => {
    if (!generatedCode?.jsx) {
      toast({
        title: "No code to optimize",
        description: "Generate code first before optimizing.",
        variant: "destructive",
      });
      return;
    }

    setIsOptimizing(true);
    try {
      const optimized = await optimizeCode(generatedCode.jsx);
      setGeneratedCode({
        ...generatedCode,
        jsx: optimized.optimizedJsx,
        readme: optimized.notes || generatedCode.readme,
      });
      toast({
        title: "Code optimized",
        description: "AI has improved accessibility and responsiveness.",
      });
    } catch (error: any) {
      toast({
        title: "Optimization failed",
        description: error.message || "Failed to optimize code.",
        variant: "destructive",
      });
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const blob = await exportProject(projectName, layout, generatedCode || undefined);
      downloadBlob(blob, `${projectName.toLowerCase().replace(/\s+/g, "-")}.zip`);
      toast({
        title: "Export complete",
        description: "Your project has been downloaded as a ZIP file.",
      });
    } catch (error: any) {
      toast({
        title: "Export failed",
        description: error.message || "Failed to export project.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    setLocation("/");
  };

  return (
    <header className="h-14 border-b bg-background flex items-center justify-between px-4 gap-4 flex-shrink-0">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-semibold text-sm hidden sm:inline">Neural UI</span>
        </div>

        <div className="hidden sm:block w-px h-6 bg-border" />

        {isEditingName ? (
          <Input
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            onBlur={() => setIsEditingName(false)}
            onKeyDown={(e) => e.key === "Enter" && setIsEditingName(false)}
            className="h-8 w-48 text-sm"
            autoFocus
            data-testid="input-project-name"
          />
        ) : (
          <button
            onClick={() => setIsEditingName(true)}
            className="text-sm font-medium hover:text-primary transition-colors truncate max-w-[200px]"
            data-testid="button-edit-project-name"
          >
            {projectName}
          </button>
        )}

        <Button
          variant="ghost"
          size="sm"
          onClick={onOpenProjects}
          className="hidden md:inline-flex"
          data-testid="button-open-projects"
        >
          <FolderOpen className="w-4 h-4 mr-2" />
          Projects
        </Button>
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={handleSave}
          disabled={isSaving}
          data-testid="button-save"
        >
          {isSaving ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          <span className="hidden sm:inline">Save</span>
        </Button>

        <Button
          variant="default"
          size="sm"
          onClick={handleGenerate}
          disabled={isGenerating || layout.components.length === 0}
          data-testid="button-generate"
        >
          {isGenerating ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Sparkles className="w-4 h-4 mr-2" />
          )}
          <span className="hidden sm:inline">Generate</span>
        </Button>

        <Button
          variant="secondary"
          size="sm"
          onClick={handleOptimize}
          disabled={isOptimizing || !generatedCode?.jsx}
          data-testid="button-optimize"
        >
          {isOptimizing ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Zap className="w-4 h-4 mr-2" />
          )}
          <span className="hidden sm:inline">Optimize</span>
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={handleExport}
          disabled={isExporting}
          data-testid="button-export"
        >
          {isExporting ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Download className="w-4 h-4 mr-2" />
          )}
          <span className="hidden sm:inline">Export</span>
        </Button>

        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleDarkMode}
          data-testid="button-toggle-dark-mode"
        >
          {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" data-testid="button-user-menu">
              <User className="w-4 h-4" />
              <ChevronDown className="w-3 h-3 ml-1" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            {user && (
              <>
                <div className="px-2 py-1.5">
                  <p className="text-sm font-medium truncate">{user.email}</p>
                </div>
                <DropdownMenuSeparator />
              </>
            )}
            <DropdownMenuItem onClick={handleSignOut} data-testid="button-signout">
              <LogOut className="w-4 h-4 mr-2" />
              Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
