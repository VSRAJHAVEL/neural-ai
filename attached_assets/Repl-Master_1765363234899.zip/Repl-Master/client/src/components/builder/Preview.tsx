import { useState } from "react";
import { useProject } from "@/context/ProjectContext";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { LayoutComponent } from "@shared/schema";
import { cn } from "@/lib/utils";
import {
  Eye,
  Code2,
  Smartphone,
  Tablet,
  Monitor,
  Copy,
  Check,
  RefreshCw,
} from "lucide-react";

type ViewportSize = "mobile" | "tablet" | "desktop";

const VIEWPORT_WIDTHS: Record<ViewportSize, string> = {
  mobile: "375px",
  tablet: "768px",
  desktop: "100%",
};

function RenderComponent({ component }: { component: LayoutComponent }) {
  const { type, props } = component;

  switch (type) {
    case "container":
      return (
        <div
          style={{
            backgroundColor: props.backgroundColor,
            padding: props.padding,
            borderRadius: props.borderRadius,
            width: props.width || "100%",
          }}
          className="min-h-[40px]"
        >
          {props.text && <span>{props.text}</span>}
        </div>
      );

    case "text":
      return (
        <p
          style={{
            color: props.color,
            fontSize: props.fontSize,
            textAlign: props.alignment || "left",
            padding: props.padding,
          }}
        >
          {props.text || "Text content"}
        </p>
      );

    case "button":
      return (
        <button
          style={{
            backgroundColor: props.backgroundColor,
            color: props.color,
            padding: props.padding,
            borderRadius: props.borderRadius,
          }}
          className="font-medium transition-opacity hover:opacity-90"
        >
          {props.text || "Button"}
        </button>
      );

    case "image":
      return (
        <img
          src={props.imageUrl || "https://via.placeholder.com/300x200"}
          alt="User content"
          style={{
            width: props.width,
            height: props.height,
            borderRadius: props.borderRadius,
          }}
          className="object-cover"
        />
      );

    case "card":
      return (
        <div
          style={{
            backgroundColor: props.backgroundColor,
            padding: props.padding,
            borderRadius: props.borderRadius,
          }}
          className="shadow-sm border"
        >
          <h3 className="font-medium" style={{ color: props.color }}>
            {props.text || "Card Title"}
          </h3>
        </div>
      );

    case "navbar":
      return (
        <nav
          style={{
            backgroundColor: props.backgroundColor,
            color: props.color,
            padding: props.padding,
          }}
          className="flex items-center justify-between"
        >
          <span className="font-medium">{props.text || "Brand"}</span>
          <div className="flex gap-4 text-sm">
            <span className="opacity-80">Home</span>
            <span className="opacity-80">About</span>
            <span className="opacity-80">Contact</span>
          </div>
        </nav>
      );

    default:
      return null;
  }
}

export function Preview() {
  const { layout, generatedCode } = useProject();
  const [viewport, setViewport] = useState<ViewportSize>("desktop");
  const [copied, setCopied] = useState(false);

  const handleCopyCode = async () => {
    if (generatedCode?.jsx) {
      await navigator.clipboard.writeText(generatedCode.jsx);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-muted/30 overflow-hidden">
      <Tabs defaultValue="preview" className="flex-1 flex flex-col">
        <div className="p-4 border-b bg-background flex items-center justify-between gap-4">
          <TabsList>
            <TabsTrigger value="preview" className="text-xs">
              <Eye className="w-3 h-3 mr-1" />
              Preview
            </TabsTrigger>
            <TabsTrigger value="code" className="text-xs" disabled={!generatedCode?.jsx}>
              <Code2 className="w-3 h-3 mr-1" />
              Code
            </TabsTrigger>
          </TabsList>

          <div className="flex items-center gap-1">
            {[
              { size: "mobile" as ViewportSize, icon: Smartphone },
              { size: "tablet" as ViewportSize, icon: Tablet },
              { size: "desktop" as ViewportSize, icon: Monitor },
            ].map(({ size, icon: Icon }) => (
              <Button
                key={size}
                variant={viewport === size ? "default" : "ghost"}
                size="icon"
                className="h-8 w-8"
                onClick={() => setViewport(size)}
                data-testid={`button-viewport-${size}`}
              >
                <Icon className="w-4 h-4" />
              </Button>
            ))}
          </div>
        </div>

        <TabsContent value="preview" className="flex-1 m-0 overflow-hidden">
          <div className="h-full flex items-start justify-center p-6 overflow-auto">
            <div
              className="bg-white rounded-lg shadow-sm border transition-all duration-300 overflow-hidden"
              style={{
                width: VIEWPORT_WIDTHS[viewport],
                maxWidth: "100%",
                minHeight: "400px",
              }}
            >
              {layout.components.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground">
                  <Eye className="w-8 h-8 mb-2 opacity-50" />
                  <p className="text-sm">Add components to see preview</p>
                </div>
              ) : (
                <div className="space-y-0">
                  {layout.components.map((component) => (
                    <RenderComponent key={component.id} component={component} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="code" className="flex-1 m-0 overflow-hidden flex flex-col">
          {generatedCode?.jsx ? (
            <>
              <div className="p-3 border-b bg-background flex items-center justify-between">
                <span className="text-xs text-muted-foreground font-mono">GeneratedComponent.jsx</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleCopyCode}
                  data-testid="button-copy-code"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-2" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
              <ScrollArea className="flex-1">
                <pre className="p-4 text-sm font-mono text-foreground whitespace-pre-wrap break-words">
                  {generatedCode.jsx}
                </pre>
              </ScrollArea>
              {generatedCode.readme && (
                <div className="p-4 border-t bg-muted/50">
                  <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
                    Notes
                  </h4>
                  <p className="text-sm text-muted-foreground">{generatedCode.readme}</p>
                </div>
              )}
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
              <Code2 className="w-8 h-8 mb-2 opacity-50" />
              <p className="text-sm">Generate code to see it here</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
