import { createContext, useContext, useState, ReactNode, useCallback } from "react";
import type { LayoutComponent, LayoutJson, GeneratedCode, ComponentType, ComponentProps } from "@shared/schema";
import { nanoid } from "@/lib/utils";

interface ProjectContextType {
  projectId: string;
  projectName: string;
  layout: LayoutJson;
  selectedComponentId: string | null;
  generatedCode: GeneratedCode | null;
  isGenerating: boolean;
  isOptimizing: boolean;
  setProjectId: (id: string) => void;
  setProjectName: (name: string) => void;
  setLayout: (layout: LayoutJson) => void;
  setSelectedComponentId: (id: string | null) => void;
  setGeneratedCode: (code: GeneratedCode | null) => void;
  setIsGenerating: (loading: boolean) => void;
  setIsOptimizing: (loading: boolean) => void;
  addComponent: (type: ComponentType) => void;
  updateComponent: (id: string, props: Partial<ComponentProps>) => void;
  removeComponent: (id: string) => void;
  moveComponent: (fromIndex: number, toIndex: number) => void;
  getSelectedComponent: () => LayoutComponent | null;
  resetProject: () => void;
}

const defaultLayout: LayoutJson = { components: [] };

const ProjectContext = createContext<ProjectContextType | null>(null);

function getDefaultProps(type: ComponentType): ComponentProps {
  switch (type) {
    case "container":
      return {
        backgroundColor: "#f8fafc",
        padding: "16px",
        width: "100%",
        borderRadius: "8px",
      };
    case "text":
      return {
        text: "Enter your text here",
        color: "#1e293b",
        fontSize: "16px",
        alignment: "left",
      };
    case "button":
      return {
        text: "Click me",
        backgroundColor: "#6366f1",
        color: "#ffffff",
        padding: "12px 24px",
        borderRadius: "8px",
      };
    case "image":
      return {
        imageUrl: "https://via.placeholder.com/300x200",
        width: "300px",
        height: "200px",
        borderRadius: "8px",
      };
    case "card":
      return {
        text: "Card Title",
        backgroundColor: "#ffffff",
        padding: "24px",
        borderRadius: "12px",
      };
    case "navbar":
      return {
        text: "My Website",
        backgroundColor: "#1e293b",
        color: "#ffffff",
        padding: "16px 24px",
      };
    default:
      return {};
  }
}

export function ProjectProvider({ children }: { children: ReactNode }) {
  const [projectId, setProjectId] = useState<string>(nanoid());
  const [projectName, setProjectName] = useState<string>("Untitled Project");
  const [layout, setLayout] = useState<LayoutJson>(defaultLayout);
  const [selectedComponentId, setSelectedComponentId] = useState<string | null>(null);
  const [generatedCode, setGeneratedCode] = useState<GeneratedCode | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);

  const addComponent = useCallback((type: ComponentType) => {
    const newComponent: LayoutComponent = {
      id: nanoid(),
      type,
      props: getDefaultProps(type),
    };

    setLayout((prev) => ({
      components: [...prev.components, newComponent],
    }));

    setSelectedComponentId(newComponent.id);
  }, []);

  const updateComponent = useCallback((id: string, props: Partial<ComponentProps>) => {
    setLayout((prev) => ({
      components: prev.components.map((comp) =>
        comp.id === id ? { ...comp, props: { ...comp.props, ...props } } : comp
      ),
    }));
  }, []);

  const removeComponent = useCallback((id: string) => {
    setLayout((prev) => ({
      components: prev.components.filter((comp) => comp.id !== id),
    }));
    setSelectedComponentId((prev) => (prev === id ? null : prev));
  }, []);

  const moveComponent = useCallback((fromIndex: number, toIndex: number) => {
    setLayout((prev) => {
      const len = prev.components.length;
      if (fromIndex < 0 || fromIndex >= len || toIndex < 0 || toIndex >= len) {
        return prev;
      }
      if (fromIndex === toIndex) {
        return prev;
      }
      const newComponents = [...prev.components];
      const [removed] = newComponents.splice(fromIndex, 1);
      newComponents.splice(toIndex, 0, removed);
      return { components: newComponents };
    });
  }, []);

  const getSelectedComponent = useCallback(() => {
    if (!selectedComponentId) return null;
    return layout.components.find((comp) => comp.id === selectedComponentId) || null;
  }, [layout.components, selectedComponentId]);

  const resetProject = useCallback(() => {
    setProjectId(nanoid());
    setProjectName("Untitled Project");
    setLayout(defaultLayout);
    setSelectedComponentId(null);
    setGeneratedCode(null);
  }, []);

  return (
    <ProjectContext.Provider
      value={{
        projectId,
        projectName,
        layout,
        selectedComponentId,
        generatedCode,
        isGenerating,
        isOptimizing,
        setProjectId,
        setProjectName,
        setLayout,
        setSelectedComponentId,
        setGeneratedCode,
        setIsGenerating,
        setIsOptimizing,
        addComponent,
        updateComponent,
        removeComponent,
        moveComponent,
        getSelectedComponent,
        resetProject,
      }}
    >
      {children}
    </ProjectContext.Provider>
  );
}

export function useProject() {
  const context = useContext(ProjectContext);
  if (!context) {
    throw new Error("useProject must be used within a ProjectProvider");
  }
  return context;
}
