import type { LayoutJson, GeneratedCode, OptimizedCode } from "@shared/schema";
import { apiRequest } from "./queryClient";

export async function generateCode(layoutJson: LayoutJson): Promise<GeneratedCode> {
  const response = await apiRequest("POST", "/api/generate", { layoutJson });
  return response.json();
}

export async function optimizeCode(jsx: string): Promise<OptimizedCode> {
  const response = await apiRequest("POST", "/api/optimize", { jsx });
  return response.json();
}

export async function exportProject(
  projectName: string,
  layoutJson: LayoutJson,
  generatedCode?: GeneratedCode
): Promise<Blob> {
  const response = await apiRequest("POST", "/api/export", {
    projectName,
    layoutJson,
    generatedCode,
  });
  return response.blob();
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
