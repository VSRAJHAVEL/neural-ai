import { initializeApp, getApps, getApp, FirebaseApp } from "firebase/app";
import {
  getAuth,
  Auth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User,
  GoogleAuthProvider,
  signInWithPopup,
} from "firebase/auth";
import {
  getFirestore,
  Firestore,
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  query,
  where,
  orderBy,
} from "firebase/firestore";
import type { Project, InsertProject, LayoutJson, GeneratedCode } from "@shared/schema";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

export function isFirebaseConfigured(): boolean {
  return !!(
    import.meta.env.VITE_FIREBASE_API_KEY &&
    import.meta.env.VITE_FIREBASE_PROJECT_ID &&
    import.meta.env.VITE_FIREBASE_APP_ID
  );
}

export function initializeFirebase() {
  if (!isFirebaseConfigured()) {
    console.warn("Firebase not configured. Please add Firebase environment variables.");
    return { app: null, auth: null, db: null };
  }

  if (!app) {
    app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
  }

  return { app, auth, db };
}

export function getFirebaseAuth(): Auth | null {
  if (!auth) {
    initializeFirebase();
  }
  return auth;
}

export function getFirebaseDb(): Firestore | null {
  if (!db) {
    initializeFirebase();
  }
  return db;
}

export async function signInWithEmail(email: string, password: string): Promise<User> {
  const authInstance = getFirebaseAuth();
  if (!authInstance) {
    throw new Error("Firebase not configured");
  }
  const result = await signInWithEmailAndPassword(authInstance, email, password);
  return result.user;
}

export async function signUpWithEmail(email: string, password: string): Promise<User> {
  const authInstance = getFirebaseAuth();
  if (!authInstance) {
    throw new Error("Firebase not configured");
  }
  const result = await createUserWithEmailAndPassword(authInstance, email, password);
  return result.user;
}

export async function signInWithGoogle(): Promise<User> {
  const authInstance = getFirebaseAuth();
  if (!authInstance) {
    throw new Error("Firebase not configured");
  }
  const provider = new GoogleAuthProvider();
  const result = await signInWithPopup(authInstance, provider);
  return result.user;
}

export async function logOut(): Promise<void> {
  const authInstance = getFirebaseAuth();
  if (authInstance) {
    await signOut(authInstance);
  }
}

export function subscribeToAuthChanges(callback: (user: User | null) => void): () => void {
  const authInstance = getFirebaseAuth();
  if (!authInstance) {
    callback(null);
    return () => {};
  }
  return onAuthStateChanged(authInstance, callback);
}

export async function getUserProjects(userId: string): Promise<Project[]> {
  const firestore = getFirebaseDb();
  if (!firestore) {
    throw new Error("Firestore not configured");
  }

  const projectsRef = collection(firestore, "users", userId, "projects");
  const q = query(projectsRef, orderBy("updatedAt", "desc"));
  const snapshot = await getDocs(q);

  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  })) as Project[];
}

export async function getProject(userId: string, projectId: string): Promise<Project | null> {
  const firestore = getFirebaseDb();
  if (!firestore) {
    throw new Error("Firestore not configured");
  }

  const projectRef = doc(firestore, "users", userId, "projects", projectId);
  const snapshot = await getDoc(projectRef);

  if (!snapshot.exists()) {
    return null;
  }

  return { id: snapshot.id, ...snapshot.data() } as Project;
}

export async function saveProject(
  userId: string,
  projectId: string,
  data: {
    name: string;
    layout: LayoutJson;
    generatedCode?: GeneratedCode;
  }
): Promise<void> {
  const firestore = getFirebaseDb();
  if (!firestore) {
    throw new Error("Firestore not configured");
  }

  const projectRef = doc(firestore, "users", userId, "projects", projectId);
  const now = Date.now();

  await setDoc(
    projectRef,
    {
      ...data,
      userId,
      updatedAt: now,
      createdAt: now,
    },
    { merge: true }
  );
}

export async function deleteProject(userId: string, projectId: string): Promise<void> {
  const firestore = getFirebaseDb();
  if (!firestore) {
    throw new Error("Firestore not configured");
  }

  const projectRef = doc(firestore, "users", userId, "projects", projectId);
  await deleteDoc(projectRef);
}

export { type User };
