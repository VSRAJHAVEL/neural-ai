import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { ProjectProvider, useProject } from "@/context/ProjectContext";
import { Topbar } from "@/components/builder/Topbar";
import { Sidebar } from "@/components/builder/Sidebar";
import { Canvas } from "@/components/builder/Canvas";
import { PropertiesPanel } from "@/components/builder/PropertiesPanel";
import { Preview } from "@/components/builder/Preview";
import { ProjectList } from "@/components/builder/ProjectList";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { ComponentType } from "@shared/schema";
import {
  Layers,
  Eye,
  Menu,
  Plus,
  Square,
  Type,
  MousePointer2,
  Image,
  CreditCard,
  Navigation,
  Settings2,
} from "lucide-react";

const MOBILE_COMPONENTS: { type: ComponentType; icon: React.ReactNode; label: string }[] = [
  { type: "container", icon: <Square className="w-4 h-4" />, label: "Container" },
  { type: "text", icon: <Type className="w-4 h-4" />, label: "Text" },
  { type: "button", icon: <MousePointer2 className="w-4 h-4" />, label: "Button" },
  { type: "image", icon: <Image className="w-4 h-4" />, label: "Image" },
  { type: "card", icon: <CreditCard className="w-4 h-4" />, label: "Card" },
  { type: "navbar", icon: <Navigation className="w-4 h-4" />, label: "Navbar" },
];

function MobileComponentBar() {
  const { addComponent } = useProject();

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background border-t p-2 lg:hidden z-50">
      <div className="flex gap-1 overflow-x-auto pb-safe">
        {MOBILE_COMPONENTS.map(({ type, icon, label }) => (
          <Button
            key={type}
            variant="ghost"
            size="sm"
            className="flex-shrink-0 flex-col h-auto py-2 px-3 gap-1"
            onClick={() => addComponent(type)}
            data-testid={`mobile-add-${type}`}
          >
            {icon}
            <span className="text-[10px]">{label}</span>
          </Button>
        ))}
      </div>
    </div>
  );
}

function MobilePropertiesSheet() {
  const { getSelectedComponent, selectedComponentId } = useProject();
  const selectedComponent = getSelectedComponent();

  if (!selectedComponent) return null;

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="fixed bottom-20 right-4 z-40 lg:hidden shadow-lg"
          data-testid="button-mobile-properties"
        >
          <Settings2 className="w-4 h-4" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-80 p-0">
        <PropertiesPanel />
      </SheetContent>
    </Sheet>
  );
}

function BuilderContent() {
  const [showProjectList, setShowProjectList] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== "undefined") {
      return document.documentElement.classList.contains("dark");
    }
    return false;
  });
  const [activeTab, setActiveTab] = useState<"canvas" | "preview">("canvas");

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    setIsDarkMode((prev) => !prev);
  };

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <Topbar
        onOpenProjects={() => setShowProjectList(true)}
        isDarkMode={isDarkMode}
        onToggleDarkMode={toggleDarkMode}
      />

      <div className="flex-1 flex overflow-hidden">
        <div className="hidden lg:block">
          <Sidebar />
        </div>

        <div className="flex-1 flex flex-col lg:hidden overflow-hidden">
          <Tabs
            value={activeTab}
            onValueChange={(v) => setActiveTab(v as "canvas" | "preview")}
            className="flex-1 flex flex-col overflow-hidden"
          >
            <TabsList className="mx-4 my-2 grid grid-cols-2">
              <TabsTrigger value="canvas">
                <Layers className="w-4 h-4 mr-2" />
                Canvas
              </TabsTrigger>
              <TabsTrigger value="preview">
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </TabsTrigger>
            </TabsList>

            <TabsContent value="canvas" className="flex-1 overflow-hidden m-0">
              <Canvas />
            </TabsContent>

            <TabsContent value="preview" className="flex-1 m-0 overflow-hidden">
              <Preview />
            </TabsContent>
          </Tabs>

          <div className="h-16" />
        </div>

        <div className="hidden lg:flex flex-1">
          <Canvas />
          <Preview />
        </div>

        <div className="hidden lg:block">
          <PropertiesPanel />
        </div>
      </div>

      <MobileComponentBar />
      <MobilePropertiesSheet />

      <ProjectList open={showProjectList} onOpenChange={setShowProjectList} />
    </div>
  );
}

export default function BuilderPage() {
  return (
    <ProjectProvider>
      <BuilderContent />
    </ProjectProvider>
  );
}
