# Neural UI - AI-Powered Website Builder

## Overview
Neural UI is a full-stack web application that provides an AI-powered visual website builder. Users can drag and drop components to design layouts, and the AI generates production-ready React + Tailwind CSS code.

## Tech Stack
- **Frontend**: React 18 + Vite + TypeScript + Tailwind CSS
- **Backend**: Node.js + Express + TypeScript
- **Authentication**: Firebase Auth (email/password + Google)
- **Database**: Firebase Firestore (user projects)
- **AI**: Groq API (LLaMA-3-8b model) for code generation

## Project Structure
```
client/
├── src/
│   ├── components/
│   │   ├── builder/      # Builder UI components
│   │   │   ├── Canvas.tsx
│   │   │   ├── Preview.tsx
│   │   │   ├── PropertiesPanel.tsx
│   │   │   ├── Sidebar.tsx
│   │   │   ├── Topbar.tsx
│   │   │   └── ProjectList.tsx
│   │   └── ui/           # Shadcn UI components
│   ├── context/
│   │   ├── AuthContext.tsx    # Firebase auth state
│   │   └── ProjectContext.tsx # Builder state management
│   ├── lib/
│   │   ├── api.ts        # API client functions
│   │   ├── firebase.ts   # Firebase configuration
│   │   ├── queryClient.ts
│   │   └── utils.ts
│   ├── pages/
│   │   ├── LoginPage.tsx
│   │   ├── BuilderPage.tsx
│   │   └── not-found.tsx
│   └── App.tsx
server/
├── routes.ts     # API endpoints
├── index.ts      # Express server
└── storage.ts    # Storage interface
shared/
└── schema.ts     # Shared TypeScript types
```

## Key Features
1. **Login/Register**: Firebase authentication with email/password and Google sign-in
2. **Component Palette**: Drag-and-drop components (container, text, button, image, card, navbar)
3. **Visual Canvas**: Add, select, reorder, and delete components
4. **Properties Panel**: Edit component styles and content
5. **AI Code Generation**: Convert layout to React + Tailwind code using Groq
6. **AI Optimization**: Improve code for accessibility and responsiveness
7. **Project Management**: Save/load projects from Firestore
8. **Export**: Download project as a ZIP file

## API Endpoints
- `POST /api/generate` - Generate React code from layout JSON
- `POST /api/optimize` - Optimize generated code
- `POST /api/export` - Export project as ZIP file

## Environment Variables
Required secrets (in Replit Secrets):
- `GROQ_API_KEY` - Groq API key for AI generation
- `VITE_FIREBASE_API_KEY` - Firebase API key
- `VITE_FIREBASE_PROJECT_ID` - Firebase project ID
- `VITE_FIREBASE_APP_ID` - Firebase app ID

## Running the App
The app runs on port 5000 with `npm run dev` which starts both frontend and backend.

## User Preferences
- Using Inter font for UI
- Purple/Indigo primary color scheme
- Clean, modern interface inspired by Linear and Figma
