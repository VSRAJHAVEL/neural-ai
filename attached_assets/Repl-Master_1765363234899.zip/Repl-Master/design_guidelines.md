# Neural UI - Design Guidelines

## Design Approach
**Reference-Based**: Drawing inspiration from **Linear** (clean productivity aesthetics), **Figma** (builder interface patterns), and **Notion** (component-based interactions). This creates a professional, focused environment optimized for the builder workflow.

## Core Design Principles
1. **Clarity Over Decoration** - Every element serves the builder workflow
2. **Spatial Hierarchy** - Clear zones for different functions (palette, canvas, properties)
3. **Visual Quietness** - Muted interface lets user content stand out
4. **Responsive Precision** - Exact measurements for professional feel

---

## Typography System

**Font Stack**: Inter (via Google Fonts CDN)
- **Headers/Labels**: 600 weight, tracking tight (-0.02em)
- **Body/Properties**: 400 weight, tracking normal
- **Canvas Component Labels**: 500 weight, 14px

**Size Scale**:
- Panel Headers: 13px
- Component Labels: 12px  
- Properties Labels: 11px uppercase
- Button Text: 14px
- Canvas Component Text: varies by component type

---

## Layout System

**Spacing Primitives**: Tailwind units of **2, 3, 4, 6, 8** exclusively
- Panel padding: p-4
- Component gaps: gap-3
- Section spacing: space-y-6
- Tight spacing: gap-2

**Grid Structure**:
```
┌─────────────────────────────────────────────────┐
│  Topbar (h-14, border-b)                        │
├──────────┬───────────────────────┬──────────────┤
│ Sidebar  │   Canvas              │  Properties  │
│ w-64     │   flex-1              │  w-80        │
│          │   (center focus)      │              │
└──────────┴───────────────────────┴──────────────┘
```

**Breakpoints**:
- Desktop (lg): Full 3-column layout
- Tablet (md): Collapsible sidebar, stack properties below
- Mobile: Full-stack, drawer navigation

---

## Component Library

### Topbar
- Height: 56px (h-14)
- Contains: Project name (editable inline), Save, Generate AI, Optimize AI, Export buttons
- Layout: flex justify-between items-center px-6
- Right cluster: Button group with gap-3

### Sidebar (Component Palette)
- Fixed width: 256px (w-64)
- Sections: "Components" header, scrollable list
- Each component item: 
  - Height: 48px, rounded-lg, px-4
  - Icon (20px) + Label
  - Hover: subtle background shift
  - Drag handle indicator on left edge

### Canvas (Center)
- Background: Subtle dot pattern or light grid
- Component representation: White cards with border, rounded-xl, shadow-sm
- Selected state: Ring-2 in accent color, shadow-md
- Empty state: Centered dashed border box with "Drop components here" text
- Zoom controls: Bottom-right floating buttons (50%, 75%, 100%, 125%)

### Properties Panel
- Width: 320px (w-80)
- Sections stack vertically with space-y-4
- Form elements: Native-style inputs with border-2, rounded-md, focus:ring-2
- Labels above inputs, 11px uppercase, tracking-wide
- Color pickers: Click to expand, swatch preview

### Preview Pane
- Toggle between breakpoints: Row of device icons (mobile/tablet/desktop)
- Active device: Highlighted with accent color
- Preview frame: White background, centered, appropriate width for device
- Refresh button in corner

### Login Page
- Centered card: max-w-md, rounded-2xl, shadow-xl
- Form inputs: h-11, rounded-lg
- Primary button: Full width, h-11
- Background: Subtle gradient or texture

---

## Interactive States

**Buttons**:
- Primary (Generate/Save): Solid background, h-10, px-6, rounded-lg, font-medium
- Secondary: Border-2, same dimensions
- Icon buttons: w-10, h-10, rounded-lg, icon centered

**Drag & Drop**:
- Dragging: Reduce opacity to 0.5, add shadow-2xl
- Drop target valid: Dashed border becomes solid accent color, background tint
- Drop target invalid: Red border pulse

**Selection**:
- Canvas components: Ring-2 + shadow-md elevation
- Sidebar component: Background fill on click
- Properties fields: Focus ring-2 in accent color

---

## Visual Treatments

**Borders**: 1px solid, minimal contrast against backgrounds
**Shadows**: 
- Cards: shadow-sm default, shadow-md on hover/selected
- Modals: shadow-2xl
- Dropdowns: shadow-lg

**Corners**: 
- Panels/Cards: rounded-xl (12px)
- Buttons/Inputs: rounded-lg (8px)
- Small chips: rounded-md (6px)

**Elevation Layers**:
1. Background (canvas area)
2. Panels (sidebars, properties)
3. Components on canvas
4. Modals/overlays
5. Tooltips/notifications

---

## Animations

**Minimal & Purposeful Only**:
- Panel transitions: Duration 200ms, ease-out
- Button hover: Scale 1.02, duration 150ms
- Component drag: Smooth transform, 100ms
- No page transitions, no decorative animations

---

## Images

**Hero Image**: Login page only - Full-bleed background image showing abstract code/neural network visualization, overlaid with semi-transparent dark gradient (0.6 opacity) for text readability.

**Component Icons**: Use Heroicons (outline style) via CDN for all sidebar component types and toolbar actions. 20px size consistently.

**Empty States**: Illustration placeholder in canvas when no components added - simple line art of building blocks or layout grid (inline SVG, monochrome).

No other images needed - interface-focused application.

---

## Accessibility

- All interactive elements: min 44px touch target
- Focus indicators: 2px ring on all focusable elements
- ARIA labels on icon-only buttons
- Keyboard navigation: Tab through panels, Enter to select, Escape to deselect
- Screen reader announcements for drag-drop actions