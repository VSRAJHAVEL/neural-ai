import type { Express } from "express";
import { createServer, type Server } from "http";
import axios from "axios";
import JSZip from "jszip";
import {
  GenerateRequestSchema,
  OptimizeRequestSchema,
  ExportRequestSchema,
  GeneratedCodeSchema,
  OptimizedCodeSchema,
} from "@shared/schema";
import type { LayoutJson, GeneratedCode } from "@shared/schema";

const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const GROQ_MODEL = "llama3-8b-8192";

function generatePrompt(layoutJson: LayoutJson): string {
  return `You are an expert React + Tailwind CSS developer.

Convert this layout JSON into a production-ready React functional component using Tailwind CSS utility classes.

Requirements:
1. Create a clean, semantic React component
2. Use Tailwind CSS for all styling
3. Make it responsive and accessible
4. Include proper ARIA labels where needed

Output STRICTLY valid JSON with these keys:
{
  "jsx": "// Your complete React component code here",
  "css": "",
  "readme": "Brief usage instructions"
}

Important: Output ONLY the JSON object, no markdown code blocks or additional text.

Layout JSON:
${JSON.stringify(layoutJson, null, 2)}`;
}

function optimizePrompt(jsx: string): string {
  return `You are a frontend optimization expert.

Improve this React JSX code for:
- Mobile-first responsiveness (use Tailwind responsive prefixes like sm:, md:, lg:)
- Accessibility (semantic HTML, ARIA attributes where needed, proper heading hierarchy)
- Clean code structure and readability
- Performance best practices

Output STRICTLY valid JSON with these keys:
{
  "optimizedJsx": "// Your optimized React component code here",
  "notes": "Brief summary of improvements made"
}

Important: Output ONLY the JSON object, no markdown code blocks or additional text.

Code to optimize:
${jsx}`;
}

async function callGroq(prompt: string): Promise<string> {
  const apiKey = process.env.GROQ_API_KEY;
  
  if (!apiKey) {
    throw new Error("GROQ_API_KEY is not configured. Please add your Groq API key to the Secrets tab.");
  }

  try {
    const response = await axios.post(
      GROQ_API_URL,
      {
        model: GROQ_MODEL,
        messages: [{ role: "user", content: prompt }],
        temperature: 0.1,
        max_tokens: 4096,
      },
      {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        timeout: 60000,
      }
    );

    return response.data.choices[0].message.content;
  } catch (error: any) {
    if (error.response?.status === 401) {
      throw new Error("Invalid GROQ_API_KEY. Please check your API key.");
    }
    if (error.response?.status === 429) {
      throw new Error("Rate limit exceeded. Please try again in a moment.");
    }
    throw new Error(`AI service error: ${error.message}`);
  }
}

function parseJsonResponse(content: string): any {
  let cleanContent = content.trim();
  
  const jsonBlockMatch = cleanContent.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (jsonBlockMatch) {
    cleanContent = jsonBlockMatch[1].trim();
  }
  
  const jsonObjectMatch = cleanContent.match(/\{[\s\S]*\}/);
  if (jsonObjectMatch) {
    cleanContent = jsonObjectMatch[0];
  }

  try {
    return JSON.parse(cleanContent);
  } catch (error) {
    throw new Error(`Failed to parse AI response. The AI returned invalid JSON. Please try again.`);
  }
}

function sanitizeProjectName(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .substring(0, 50);
}

function generateProjectFiles(
  projectName: string,
  layoutJson: LayoutJson,
  generatedCode?: GeneratedCode
): Record<string, string> {
  const safeName = sanitizeProjectName(projectName) || "neural-ui-project";
  
  const componentCode = generatedCode?.jsx || `
import React from 'react';

export default function GeneratedComponent() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <h1 className="text-2xl font-bold text-gray-900">
        ${projectName}
      </h1>
      <p className="mt-2 text-gray-600">
        Add components in the builder to generate code.
      </p>
    </div>
  );
}
`.trim();

  const packageJson = {
    name: safeName,
    version: "1.0.0",
    private: true,
    type: "module",
    scripts: {
      dev: "vite",
      build: "vite build",
      preview: "vite preview",
    },
    dependencies: {
      react: "^18.2.0",
      "react-dom": "^18.2.0",
    },
    devDependencies: {
      "@vitejs/plugin-react": "^4.2.0",
      autoprefixer: "^10.4.16",
      postcss: "^8.4.32",
      tailwindcss: "^3.3.6",
      vite: "^5.0.0",
    },
  };

  const tailwindConfig = `/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {},
  },
  plugins: [],
};`;

  const postcssConfig = `export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};`;

  const viteConfig = `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
});`;

  const indexHtml = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${projectName}</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>`;

  const mainJsx = `import React from 'react';
import ReactDOM from 'react-dom/client';
import GeneratedComponent from './GeneratedComponent';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <GeneratedComponent />
  </React.StrictMode>
);`;

  const indexCss = `@tailwind base;
@tailwind components;
@tailwind utilities;

${generatedCode?.css || ""}`;

  const readme = `# ${projectName}

Generated by Neural UI - AI-Powered Website Builder

## Getting Started

1. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

2. Start development server:
   \`\`\`bash
   npm run dev
   \`\`\`

3. Build for production:
   \`\`\`bash
   npm run build
   \`\`\`

## Tech Stack

- React 18
- Tailwind CSS
- Vite

${generatedCode?.readme ? `\n## Notes\n\n${generatedCode.readme}` : ""}

## Layout JSON

\`\`\`json
${JSON.stringify(layoutJson, null, 2)}
\`\`\`
`;

  return {
    "package.json": JSON.stringify(packageJson, null, 2),
    "tailwind.config.js": tailwindConfig,
    "postcss.config.js": postcssConfig,
    "vite.config.js": viteConfig,
    "index.html": indexHtml,
    "src/main.jsx": mainJsx,
    "src/index.css": indexCss,
    "src/GeneratedComponent.jsx": componentCode,
    "README.md": readme,
  };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post("/api/generate", async (req, res) => {
    try {
      const parseResult = GenerateRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid request: " + parseResult.error.errors[0]?.message 
        });
      }

      const { layoutJson } = parseResult.data;
      const prompt = generatePrompt(layoutJson);
      const aiResponse = await callGroq(prompt);
      const parsed = parseJsonResponse(aiResponse);

      const validatedResult = GeneratedCodeSchema.safeParse({
        jsx: parsed.jsx || "",
        css: parsed.css || "",
        readme: parsed.readme || "",
      });

      if (!validatedResult.success) {
        return res.status(500).json({ 
          message: "AI generated invalid response format. Please try again." 
        });
      }

      res.json(validatedResult.data);
    } catch (error: any) {
      console.error("Generate error:", error.message);
      res.status(500).json({ message: error.message || "Failed to generate code" });
    }
  });

  app.post("/api/optimize", async (req, res) => {
    try {
      const parseResult = OptimizeRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid request: " + parseResult.error.errors[0]?.message 
        });
      }

      const { jsx } = parseResult.data;
      const prompt = optimizePrompt(jsx);
      const aiResponse = await callGroq(prompt);
      const parsed = parseJsonResponse(aiResponse);

      const validatedResult = OptimizedCodeSchema.safeParse({
        optimizedJsx: parsed.optimizedJsx || "",
        notes: parsed.notes || "",
      });

      if (!validatedResult.success) {
        return res.status(500).json({ 
          message: "AI generated invalid response format. Please try again." 
        });
      }

      res.json(validatedResult.data);
    } catch (error: any) {
      console.error("Optimize error:", error.message);
      res.status(500).json({ message: error.message || "Failed to optimize code" });
    }
  });

  app.post("/api/export", async (req, res) => {
    try {
      const parseResult = ExportRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid request: " + parseResult.error.errors[0]?.message 
        });
      }

      const { projectName, layoutJson, generatedCode } = parseResult.data;
      const files = generateProjectFiles(projectName, layoutJson, generatedCode);
      const zip = new JSZip();

      for (const [path, content] of Object.entries(files)) {
        zip.file(path, content);
      }

      const buffer = await zip.generateAsync({ type: "nodebuffer" });
      const safeName = sanitizeProjectName(projectName) || "neural-ui-project";

      res.set({
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="${safeName}.zip"`,
      });

      res.send(buffer);
    } catch (error: any) {
      console.error("Export error:", error.message);
      res.status(500).json({ message: error.message || "Failed to export project" });
    }
  });

  return httpServer;
}
